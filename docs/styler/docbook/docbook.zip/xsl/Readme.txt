Minimal (I think) subset of docbook stylesheets distro.

Dawid